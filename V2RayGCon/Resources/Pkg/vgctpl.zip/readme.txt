Update: 
2018-11-26

Usage: 
https://github.com/nobody3u/VGCTpl/wiki

